# Deploy Pneu Barato

## Netlify

Importe este repositório/ZIP no Netlify. O arquivo `netlify.toml` já define o comando `pnpm exec vite build` e a pasta publicada `dist/public`.

## Vercel

Importe este projeto na Vercel. O arquivo `vercel.json` já define o comando de build e a pasta de saída `dist/public`.

O projeto é estático, usa os assets locais em `client/public/assets` e não depende dos caminhos privados do WebDev.
