import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CarFront,
  Check,
  ChevronDown,
  ChevronRight,
  CircleGauge,
  Clock3,
  Languages,
  MapPin,
  Menu,
  MessageCircle,
  Navigation,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  Star,
  Timer,
  Wrench,
  X,
  Zap,
} from "lucide-react";

const WHATSAPP_NUMBER = "5522999576438";
const address = "Av. América Central, 507 – São Cristóvão – Cabo Frio – RJ";
const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;

const waLink = (message: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

const copy = {
  pt: {
    nav: ["Início", "Serviços", "Sobre", "Avaliações", "Localização", "Contato"],
    navIds: ["inicio", "servicos", "sobre", "avaliacoes", "localizacao", "contato"],
    lang: "Idioma",
    eyebrow: "Cabo Frio · São Cristóvão",
    heroTitle: "Pneus, alinhamento e balanceamento com preço justo.",
    heroBody: "Seu carro merece segurança, desempenho e um atendimento de confiança. Conte com a Pneu Barato em Cabo Frio.",
    quote: "Fazer orçamento",
    whatsapp: "Falar no WhatsApp",
    directions: "Como chegar",
    trust: ["Atendimento rápido", "Preço justo", "Equipe especializada", "Localização em Cabo Frio"],
    benefits: ["Serviços automotivos", "Alinhamento e balanceamento", "Preço justo", "Atendimento rápido"],
    servicesEyebrow: "Nosso know-how",
    servicesTitle: "Tudo para deixar seu carro em dia",
    servicesBody: "Serviços essenciais para mais segurança, estabilidade e desempenho na estrada.",
    request: "Solicitar orçamento",
    services: [
      ["Alinhamento", "Mais estabilidade, dirigibilidade e segurança para o seu carro.", "01"],
      ["Balanceamento", "Mais conforto ao dirigir e atenção aos detalhes que fazem diferença.", "02"],
      ["Pneus", "Orientação para encontrar a opção certa para sua rotina e seu veículo.", "03"],
      ["Serviços automotivos", "Cuidado essencial para manter seu carro pronto para a estrada.", "04"],
      ["Avaliação do veículo", "Uma análise cuidadosa para você decidir com mais segurança.", "05"],
      ["Manutenção relacionada aos pneus", "Atenção preventiva para preservar desempenho e tranquilidade.", "06"],
    ],
    featureKicker: "Performance começa no contato com o chão",
    featureTitle: "Seu carro alinhado.\nSua direção mais segura.",
    featureBody: "Na Pneu Barato, você encontra atendimento próximo, preço justo e cuidado profissional para seguir em frente com confiança.",
    featureCta: "Falar com a equipe",
    aboutEyebrow: "Por que escolher a Pneu Barato?",
    aboutTitle: "Confiança para\nseguir em frente.",
    aboutBody: "Uma loja local para quem valoriza atendimento rápido, orientação clara e serviço feito com atenção aos detalhes.",
    aboutPoints: ["Atendimento rápido", "Preço justo", "Experiência no segmento", "Equipe preparada", "Serviço com atenção aos detalhes", "Localização estratégica em Cabo Frio"],
    reviewsEyebrow: "Experiências reais",
    reviewsTitle: "Quem conhece, recomenda.",
    reviews: ["Excelente preço de qualquer serviço oferecido e feito na loja", "Boa recepção, atendimento rápido e bom preço.", "Atendimento do Beto e equipe é o diferencial do local"],
    conversionTitle: "Precisa de pneus ou serviço para o seu carro?",
    conversionBody: "Fale com a Pneu Barato e solicite seu orçamento.",
    call: "Ligar agora",
    locationEyebrow: "Visite a loja",
    locationTitle: "Estamos em Cabo Frio.",
    locationBody: "Chegue com facilidade à nossa unidade em São Cristóvão.",
    hoursTitle: "Horário de funcionamento",
    open: "Aberto",
    closed: "Fechado agora",
    today: "Hoje",
    monFri: "Segunda a sexta",
    saturday: "Sábado",
    sunday: "Domingo",
    footerLine: "Segurança, desempenho e preço justo para o seu carro.",
    footerCta: "Orçamento pelo WhatsApp",
  },
  en: {
    nav: ["Home", "Services", "About", "Reviews", "Location", "Contact"],
    navIds: ["inicio", "servicos", "sobre", "avaliacoes", "localizacao", "contato"],
    lang: "Language",
    eyebrow: "Cabo Frio · São Cristóvão",
    heroTitle: "Tires, alignment and balancing at a fair price.",
    heroBody: "Your car deserves safety, performance and trusted service. Count on Pneu Barato in Cabo Frio.",
    quote: "Get a quote",
    whatsapp: "Chat on WhatsApp",
    directions: "Get directions",
    trust: ["Fast service", "Fair pricing", "Specialized team", "Cabo Frio location"],
    benefits: ["Automotive services", "Alignment & balancing", "Fair pricing", "Fast service"],
    servicesEyebrow: "Our expertise",
    servicesTitle: "Everything to keep your car on track",
    servicesBody: "Essential services for more safety, stability and performance on the road.",
    request: "Request a quote",
    services: [["Alignment", "More stability, handling and safety for your car.", "01"], ["Balancing", "A smoother drive with care for the details that matter.", "02"], ["Tires", "Guidance to find the right option for your routine and vehicle.", "03"], ["Automotive services", "Essential care to keep your car ready for the road.", "04"], ["Vehicle assessment", "A careful evaluation so you can decide with confidence.", "05"], ["Tire-related maintenance", "Preventive care to preserve performance and peace of mind.", "06"]],
    featureKicker: "Performance starts where rubber meets the road",
    featureTitle: "A car in alignment.\nA safer drive.",
    featureBody: "At Pneu Barato, you get personal service, fair pricing and professional care to keep moving with confidence.",
    featureCta: "Talk to the team",
    aboutEyebrow: "Why choose Pneu Barato?",
    aboutTitle: "Confidence to\nmove forward.",
    aboutBody: "A local shop for people who value fast service, clear guidance and care for every detail.",
    aboutPoints: ["Fast service", "Fair pricing", "Industry experience", "Prepared team", "Detail-oriented service", "Strategic Cabo Frio location"],
    reviewsEyebrow: "Real experiences",
    reviewsTitle: "People who know us, recommend us.",
    reviews: ["Excellent price for every service offered and done at the shop", "Good reception, fast service and good price.", "Beto and the team's service is what sets this place apart"],
    conversionTitle: "Need tires or service for your car?",
    conversionBody: "Talk to Pneu Barato and request your quote.",
    call: "Call now",
    locationEyebrow: "Visit the shop",
    locationTitle: "We are in Cabo Frio.",
    locationBody: "Find us easily in São Cristóvão.",
    hoursTitle: "Opening hours",
    open: "Open",
    closed: "Closed now",
    today: "Today",
    monFri: "Monday to Friday",
    saturday: "Saturday",
    sunday: "Sunday",
    footerLine: "Safety, performance and fair pricing for your car.",
    footerCta: "Quote on WhatsApp",
  },
  es: {
    nav: ["Inicio", "Servicios", "Nosotros", "Reseñas", "Ubicación", "Contacto"],
    navIds: ["inicio", "servicos", "sobre", "avaliacoes", "localizacao", "contato"],
    lang: "Idioma",
    eyebrow: "Cabo Frio · São Cristóvão",
    heroTitle: "Neumáticos, alineación y balanceo a precio justo.",
    heroBody: "Tu auto merece seguridad, rendimiento y un servicio de confianza. Cuenta con Pneu Barato en Cabo Frio.",
    quote: "Pedir presupuesto",
    whatsapp: "Hablar por WhatsApp",
    directions: "Cómo llegar",
    trust: ["Servicio rápido", "Precio justo", "Equipo especializado", "Ubicación en Cabo Frio"],
    benefits: ["Servicios automotrices", "Alineación y balanceo", "Precio justo", "Servicio rápido"],
    servicesEyebrow: "Nuestra experiencia",
    servicesTitle: "Todo para mantener tu auto al día",
    servicesBody: "Servicios esenciales para más seguridad, estabilidad y rendimiento en la carretera.",
    request: "Pedir presupuesto",
    services: [["Alineación", "Más estabilidad, manejo y seguridad para tu auto.", "01"], ["Balanceo", "Más comodidad al conducir y atención a cada detalle.", "02"], ["Neumáticos", "Orientación para encontrar la opción adecuada para tu rutina y vehículo.", "03"], ["Servicios automotrices", "Cuidado esencial para mantener tu auto listo para la carretera.", "04"], ["Evaluación del vehículo", "Un análisis cuidadoso para decidir con más seguridad.", "05"], ["Mantenimiento de neumáticos", "Atención preventiva para preservar el rendimiento y la tranquilidad.", "06"]],
    featureKicker: "El rendimiento empieza en el contacto con el suelo",
    featureTitle: "Tu auto alineado.\nTu dirección más segura.",
    featureBody: "En Pneu Barato encuentras atención cercana, precio justo y cuidado profesional para seguir adelante con confianza.",
    featureCta: "Hablar con el equipo",
    aboutEyebrow: "¿Por qué elegir Pneu Barato?",
    aboutTitle: "Confianza para\nseguir adelante.",
    aboutBody: "Una tienda local para quienes valoran el servicio rápido, la orientación clara y la atención a los detalles.",
    aboutPoints: ["Servicio rápido", "Precio justo", "Experiencia en el segmento", "Equipo preparado", "Servicio atento a los detalles", "Ubicación estratégica en Cabo Frio"],
    reviewsEyebrow: "Experiencias reales",
    reviewsTitle: "Quien nos conoce, nos recomienda.",
    reviews: ["Excelente precio en cualquier servicio ofrecido y realizado en la tienda", "Buena recepción, atención rápida y buen precio.", "La atención de Beto y su equipo es el diferencial del lugar"],
    conversionTitle: "¿Necesitas neumáticos o servicio para tu auto?",
    conversionBody: "Habla con Pneu Barato y pide tu presupuesto.",
    call: "Llamar ahora",
    locationEyebrow: "Visita la tienda",
    locationTitle: "Estamos en Cabo Frio.",
    locationBody: "Llega fácilmente a nuestra unidad en São Cristóvão.",
    hoursTitle: "Horario de atención",
    open: "Abierto",
    closed: "Cerrado ahora",
    today: "Hoy",
    monFri: "Lunes a viernes",
    saturday: "Sábado",
    sunday: "Domingo",
    footerLine: "Seguridad, rendimiento y precio justo para tu auto.",
    footerCta: "Presupuesto por WhatsApp",
  },
} as const;

type Locale = keyof typeof copy;

function Logo() {
  return (
    <a href="#inicio" className="logo-mark" aria-label="Pneu Barato — início">
      <img className="logo-image" src="/assets/pneu-barato-logo-crop.webp" alt="Pneu Barato" />
    </a>
  );
}

function WhatsAppIcon() {
  return <MessageCircle size={17} strokeWidth={2.4} aria-hidden="true" />;
}

export default function Home() {
  const [locale, setLocale] = useState<Locale>("pt");
  const [menuOpen, setMenuOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const t = copy[locale];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    const checkHours = () => {
      const now = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
      const day = now.getDay();
      const minutes = now.getHours() * 60 + now.getMinutes();
      setIsOpen(day >= 1 && day <= 5 ? minutes >= 480 && minutes < 1080 : day === 6 ? minutes >= 480 && minutes < 720 : false);
    };
    checkHours();
    window.addEventListener("scroll", onScroll, { passive: true });
    const interval = window.setInterval(checkHours, 60_000);
    return () => { window.removeEventListener("scroll", onScroll); window.clearInterval(interval); };
  }, []);

  const heroStats = useMemo(() => [
    { icon: Timer, text: t.trust[0] },
    { icon: BadgeCheck, text: t.trust[1] },
    { icon: Wrench, text: t.trust[2] },
    { icon: MapPin, text: t.trust[3] },
  ], [t]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="topline"><div className="container topline-inner"><span><span className="status-dot" /> {isOpen ? t.open : t.closed}</span><span className="topline-hide">São Cristóvão · Cabo Frio — RJ</span><a href="tel:+5522999576438"><PhoneCall size={13} /> (22) 99957-6438</a></div></div>
      <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
        <div className="container header-inner">
          <Logo />
          <nav className={`desktop-nav ${menuOpen ? "mobile-open" : ""}`} aria-label="Navegação principal">
            {t.nav.map((item, index) => <a key={item} href={`#${t.navIds[index]}`} onClick={closeMenu}>{item}</a>)}
            <div className="mobile-language"><Languages size={14} /> <LanguagePicker locale={locale} setLocale={setLocale} label={t.lang} /></div>
          </nav>
          <div className="header-actions">
            <div className="language-picker-desktop"><Languages size={14} /><LanguagePicker locale={locale} setLocale={setLocale} label={t.lang} /></div>
            <a className="button button-primary button-small header-cta" href={waLink("Olá! Vim pelo site da Pneu Barato e gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer"><span>{t.quote}</span><ArrowUpRight size={16} /></a>
            <button className="menu-toggle" onClick={() => setMenuOpen((open) => !open)} aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button>
          </div>
        </div>
      </header>

      <main>
        <section id="inicio" className="hero-section">
          <div className="hero-grid-overlay" />
          <div className="hero-red-glow" />
          <div className="container hero-content">
            <div className="hero-copy">
              <div className="eyebrow light"><span className="eyebrow-line" />{t.eyebrow}</div>
              <h1>{t.heroTitle}</h1>
              <p className="hero-lead">{t.heroBody}</p>
              <div className="hero-actions">
                <a className="button button-red" href={waLink("Olá! Vim pelo site da Pneu Barato e gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer"><WhatsAppIcon /> {t.quote}<ArrowRight size={17} /></a>
                <a className="button button-ghost" href={waLink("Olá! Gostaria de falar com a equipe da Pneu Barato.")} target="_blank" rel="noreferrer"><WhatsAppIcon /> {t.whatsapp}</a>
              </div>
              <a className="directions-link" href={mapsUrl} target="_blank" rel="noreferrer"><Navigation size={15} /> {t.directions}<ArrowUpRight size={14} /></a>
            </div>
            <div className="hero-visual" aria-label="Roda esportiva em destaque">
              <div className="hero-image-frame"><video className="hero-video" src="/assets/pneu-barato-logo-animation.mp4" autoPlay muted loop playsInline aria-label="Animação comercial da Pneu Barato" /></div>
            </div>
          </div>
          <div className="container trust-row">{heroStats.map(({ icon: Icon, text }) => <div className="trust-item" key={text}><Icon size={16} /> <span>{text}</span></div>)}</div>
          <div className="hero-scroll"><span>Scroll para explorar</span><span className="scroll-line" /></div>
        </section>

        <section className="benefit-strip" aria-label="Benefícios">
          <div className="container benefit-grid">{t.benefits.map((benefit, index) => { const Icon = [CarFront, CircleGauge, BadgeCheck, Zap][index]; return <div className="benefit-item" key={benefit}><span className="benefit-icon"><Icon size={20} /></span><span>{benefit}</span><span className="benefit-index">0{index + 1}</span></div>; })}</div>
        </section>

        <section id="servicos" className="section section-light services-section">
          <div className="container">
            <div className="section-heading split-heading"><div><div className="eyebrow"><span className="eyebrow-line" />{t.servicesEyebrow}</div><h2>{t.servicesTitle}</h2></div><p>{t.servicesBody}</p></div>
            <div className="services-grid">{t.services.map(([title, description, number], index) => { const Icon = [CircleGauge, Zap, CarFront, Wrench, ShieldCheck, Sparkles][index]; return <article className="service-card" key={title}><span className="card-number">{number}</span><div className="service-icon"><Icon size={23} /></div><h3>{title}</h3><p>{description}</p><a href={waLink(`Olá! Gostaria de solicitar um orçamento para ${title.toLowerCase()} na Pneu Barato.`)} target="_blank" rel="noreferrer">{t.request}<ArrowUpRight size={15} /></a></article>; })}</div>
          </div>
        </section>

        <section className="feature-section">
          <div className="feature-image"><img src="/assets/pneu-barato-fachada.jpg" alt="Fachada real da Pneu Barato em Cabo Frio" /><div className="feature-image-overlay" /></div>
          <div className="container feature-container"><div className="feature-copy"><div className="eyebrow light"><span className="eyebrow-line" />{t.featureKicker}</div><h2>{t.featureTitle}</h2><p>{t.featureBody}</p><a className="button button-outline-light" href={waLink("Olá! Gostaria de falar com a equipe da Pneu Barato.")} target="_blank" rel="noreferrer">{t.featureCta}<ArrowUpRight size={16} /></a></div></div>
        </section>

        <section id="sobre" className="section section-dark about-section"><div className="container about-grid"><div className="about-aside"><div className="about-photo"><img src="/assets/pneu-barato-fachada.jpg" alt="Fachada da Pneu Barato em Cabo Frio" /><span className="about-photo-line" /></div></div><div className="about-copy"><div className="eyebrow light"><span className="eyebrow-line" />{t.aboutEyebrow}</div><h2>{t.aboutTitle}</h2><p className="large-copy">{t.aboutBody}</p><div className="points-grid">{t.aboutPoints.map((point) => <div className="point-item" key={point}><Check size={16} /><span>{point}</span></div>)}</div><a className="text-link light-link" href={waLink("Olá! Vim pelo site da Pneu Barato e gostaria de conhecer melhor os serviços.")} target="_blank" rel="noreferrer">Conheça nosso atendimento <ArrowRight size={16} /></a></div></div></section>

        <section id="avaliacoes" className="section section-light reviews-section"><div className="container"><div className="section-heading reviews-heading"><div><div className="eyebrow"><span className="eyebrow-line" />{t.reviewsEyebrow}</div><h2>{t.reviewsTitle}</h2></div><div className="rating-lockup"><span className="rating-number">5.0</span><span className="stars">★★★★★</span><span className="rating-label">Clientes que voltam</span></div></div><div className="reviews-grid">{t.reviews.map((review, index) => <article className="review-card" key={review}><div className="quote-mark">“</div><div className="review-stars">★★★★★</div><p>{review}</p><div className="review-footer"><span>Cliente Pneu Barato</span><span>0{index + 1}</span></div></article>)}</div></div></section>

        <section className="conversion-section"><div className="container conversion-inner"><div><div className="eyebrow light"><span className="eyebrow-line" />Fale com a Pneu Barato</div><h2>{t.conversionTitle}</h2><p>{t.conversionBody}</p></div><div className="conversion-actions"><a className="button button-red" href={waLink("Olá! Vim pelo site da Pneu Barato e gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer"><WhatsAppIcon /> {t.quote}</a><a className="button button-ghost" href="tel:+5522999576438"><PhoneCall size={16} /> {t.call}</a></div></div></section>

        <section id="localizacao" className="section section-light location-section"><div className="container location-grid"><div className="location-copy"><div className="eyebrow"><span className="eyebrow-line" />{t.locationEyebrow}</div><h2>{t.locationTitle}</h2><p>{t.locationBody}</p><div className="address-line"><MapPin size={20} /><span>{address}</span></div><div className="hours-card"><div className="hours-header"><span>{t.hoursTitle}</span><span className={`open-badge ${isOpen ? "active" : "inactive"}`}><span className="status-dot" /> {isOpen ? t.open : t.closed}</span></div><div className="hours-row"><span>{t.monFri}</span><b>08:00 — 18:00</b></div><div className="hours-row"><span>{t.saturday}</span><b>08:00 — 12:00</b></div><div className="hours-row muted"><span>{t.sunday}</span><b>Fechado</b></div></div><a className="button button-dark" href={mapsUrl} target="_blank" rel="noreferrer"><Navigation size={16} /> {t.directions}<ArrowUpRight size={16} /></a></div><div className="map-card map-real"><iframe title="Localização da Pneu Barato em Cabo Frio" src={`https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`} loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div></div></section>
      </main>

      <footer id="contato" className="site-footer"><div className="container footer-main"><div><Logo /><p>{t.footerLine}</p></div><div className="footer-links"><div><span className="footer-title">Navegue</span>{t.nav.slice(0, 4).map((item, index) => <a key={item} href={`#${t.navIds[index]}`}>{item}</a>)}</div><div><span className="footer-title">Contato</span><a href="tel:+5522999576438">(22) 99957-6438</a><a href={mapsUrl} target="_blank" rel="noreferrer">Av. América Central, 507</a><a href={mapsUrl} target="_blank" rel="noreferrer">São Cristóvão, Cabo Frio</a></div></div><div className="footer-cta"><span className="footer-title">Pronto para cuidar do seu carro?</span><a className="button button-red" href={waLink("Olá! Vim pelo site da Pneu Barato e gostaria de solicitar um orçamento.")} target="_blank" rel="noreferrer"><WhatsAppIcon /> {t.footerCta}</a></div></div><div className="container footer-bottom"><span>© 2026 Pneu Barato. Todos os direitos reservados.</span><span>Segurança em cada quilômetro.</span></div></footer>

      <a className="floating-whatsapp" href={waLink("Olá! Gostaria de solicitar um orçamento na Pneu Barato.")} target="_blank" rel="noreferrer" aria-label="Falar com a Pneu Barato pelo WhatsApp"><WhatsAppIcon /><span>WhatsApp</span></a>
    </div>
  );
}

function LanguagePicker({ locale, setLocale, label }: { locale: Locale; setLocale: (locale: Locale) => void; label: string }) {
  return <label className="language-picker"><span className="sr-only">{label}</span><select value={locale} onChange={(event) => setLocale(event.target.value as Locale)} aria-label={label}><option value="pt">PT</option><option value="en">EN</option><option value="es">ES</option></select><ChevronDown size={13} /></label>;
}
